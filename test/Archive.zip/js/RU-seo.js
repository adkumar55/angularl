/*!
 * Aequor SEO Tools js
 */


<style type="text/css">
  #results-container{ display:none; }
</style>